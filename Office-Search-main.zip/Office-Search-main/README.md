# Office Search

Simulation video game made using Godot for a psychology research group, enabling them to test and demonstrate
hypotheses on human cognitive abilities when performing tasks in a video game versus real-life scenarios.
